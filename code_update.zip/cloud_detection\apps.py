from django.apps import AppConfig


class CloudDetectionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cloud_detection'
